Data from the first version of the BioASQ Synergy task, in the context of BioASQ9.

- The files named testset_round_x.json are the files of the testsets released for each round (x) of the task. 
- The files named feedback_accompanying_round_x.json are the files with feedback based on the submissions in previous rounds, which were released with the testset file for each round x. For the first round, no feedback was accompanying the testset file. The feedback_final.json did not accompany any testset file, it is just provided for completeness.
- The files named golden_round_x.json are the files used for the final evaluation of systems responses in each round. For document and snipper retrieval, documents and snippets from previous feedback files are excluded.